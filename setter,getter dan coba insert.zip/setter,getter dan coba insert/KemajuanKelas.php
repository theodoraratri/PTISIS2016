<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of KemajuanKelas
 *
 * @author Bella
 */
class KemajuanKelas {
    private $Kode_jadwal;
    private $NIP;
    private $namaKelas;
    private $jam;
    private $hari;
    private $myd;
    private $kbm;
    private $mapel;
    
    function setKode_jadwal($x){
        $this->Kode_jadwal=$x;
    }
    function setNIP($x){
        $this->NIP=$x;
    }
    function setNamaKelas($x){
        $this->namaKelas=$x;
    }
    function setJam($x){
        $this->jam=$x;
    }
    function setHari($x){
        $this->hari=$x;
    }
    function setMyd($x){
        $this->myd=$x;
    }
    function setKbm($x){
        $this->kbm=$x;
    }
    function setMapel($x){
        $this->mapel=$x;
    }
    function getKode_jadwal(){
        return $this->Kode_jadwal;
    }
    function getNIP(){
        return $this->NIP;
    }
    function getNamaKelas(){
        return $this->namaKelas;
    }
    function getJam(){
        return $this->jam;
    }
    function getHari(){
        return $this->hari;
    }
    function getMyd(){
        return $this->myd;
    }
    function getKbm(){
        return $this->kbm;
    }
    function getMapel(){
        return $this->mapel;
    }
    
    public static function tambahJadwal()
}
