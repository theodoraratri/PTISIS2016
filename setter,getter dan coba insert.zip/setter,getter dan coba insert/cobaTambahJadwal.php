<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.

<?php
//include './Koneksi/Koneksi.php';
// coba inputkan jadwal baru
if (isset($_POST['simpan'])) {
    $kode_jadwal = $_POST['kode_jadwal'];
    $nip = $_POST['nip'];
    $mapel = $_POST['mapel'];
    $hari = $_POST['hari'];
    $jam = $_POST['jam'];

    //insert ke table jadwal pelajaran
    $query = "insert into pti.jadwal_pelajaran(kode_jadwal,nip,mapel,hari,jam)values
            ('$kode_jadwal','$nip','$mapel','$hari','$jam')";
    $sql = mysql_query($query) or die(mysql_error());
}
?>
--><div class="widget-title">
    <h5>Tambah Jadwal Pelajaran</h5>    
</div>


<form method="post" action="cobaTambahJadwal.php">
    <!--<form class="form-horizontal" method="post" name="lihat_kamera" enctype="multipart/form-data" >
    <!---->            <div class="control-group">
        <div class="controls"></div>
    </div>
    <div class="control-group ">
        <div class="control-group">

            <label class="control-label">Kode Jadwal</label>
            <div class="controls">
                <input type="text" name="kode_jadwal"  />
            </div>
        </div>
        <div class="control-group ">
            <label class="control-label">NIP Guru</label>
            <div class="controls"><input type="text" name="nip" />
            </div>
        </div>

        <div class="control-group ">
            <label class="control-label">Mata Pelajaran</label>
            <div class="controls">
                <input type="text" name="mapel" />
            </div>
        </div>

        <div class="control-group ">
            <label class="control-label">Hari</label>
            <div class="controls">
                <input type="text" name="hari" />
            </div>
        </div>
        <div class="control-group ">
            <label class="control-label">Jam</label>
            <div class="controls">
                <input type="text" name="jam" />
            </div>
        </div>

        <div class="form-actions">
            <input type="submit" value="Simpan Data" name="simpan" class="btn btn-success" >
        </div>
    </div>
</form>
